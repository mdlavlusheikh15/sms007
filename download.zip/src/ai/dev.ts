import { config } from 'dotenv';
config();

import '@/ai/flows/faq-chatbot.ts';